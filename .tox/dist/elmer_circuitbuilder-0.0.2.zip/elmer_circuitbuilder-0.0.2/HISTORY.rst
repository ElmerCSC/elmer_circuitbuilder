=======
History
=======

0.0.1 (2021-10-27)
------------------

* First release on PyPI.
